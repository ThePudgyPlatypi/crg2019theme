<!-- using javascript to generate all the boxes -->
<div class="home-grid-container">
</div>
<div class="mobile-grid">
</div>
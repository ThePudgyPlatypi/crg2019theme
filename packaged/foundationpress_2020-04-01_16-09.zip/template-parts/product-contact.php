<div class="print-contact-container" id="quote">
    <h2 class="print-contact-title blue yellow-line yellow-line-center text-center">Get a Personalized Quote</h3>
    <?php dynamic_sidebar("printing") ?>
</div>